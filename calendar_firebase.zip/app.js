import { db } from "./firebase.js";
document.getElementById("app").innerHTML = "Firebase calendar placeholder";
